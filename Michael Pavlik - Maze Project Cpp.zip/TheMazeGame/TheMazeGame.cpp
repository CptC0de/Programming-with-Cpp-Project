// TheMazeGame.cpp : This file contains the 'main' function. Program execution begins and ends there.
// Author: Michael Pavlik snr:2070814, anr:507445
// Maze solving agent using DFS algorithm


#include <iostream>
#include <vector>
#include <stack>
#include <fstream>
#include <string>

using namespace std;

// Enum for different cell types in the maze
enum CellType {
    EMPTY = 0,
    WALL = 1,
    START = 2,
    GOAL = 3,
    GOGGLES = 4,
    SPEED_POTION = 5,
    FOG = 6,
    SLOWPOKE_POTION = 7,
    AGENT = 8,
};


// Enum for different directions the agent can move
enum Direction {
    UP,
    DOWN,
    LEFT,
    RIGHT,
};

// Struct to represent a position in the maze
struct Position {
    int row;
    int col;
};


// Class to represent the maze and agent's actions
class Maze {
private:
    vector<vector<CellType>> maze;     // Maze grid
    vector<vector<bool>> visited;      // Grid to mark visited cells
    Position start;                    // Starting position
    Position goal;                     // Goal position
    stack<Position> pathStack;         // Stack to keep track of the path
    int perceptiveField = 1;           // Initial perceptive field
    int stepWidth = 1;                 // Initial step width
    int score = 0;                     // Score of the agent
    Direction direction = UP;          // Initial direction


    // Function to check if a move is valid
    bool isValidMove(int row, int col) const {
        return row >= 0 && row < maze.size() && col >= 0 && col < maze[0].size() && maze[row][col] != WALL && !visited[row][col];
    }

    // Function to mark a cell as visited
    void markVisited(int row, int col) {
        visited[row][col] = true;
    }

    // Function to initialize the visited grid
    void initializeVisited() {
        visited.resize(maze.size(), vector<bool>(maze[0].size(), false));
    }

    // Function to display the maze with the agent's position
    void displayAgent(Position agentPos) const {
        vector<vector<CellType>> tempMaze = maze;  // Create a temporary copy
        tempMaze[agentPos.row][agentPos.col] = AGENT;

        // Display the maze with the agent at its current position
        for (const auto& row : tempMaze) {
            for (const auto& cell : row) {
                string symbol;

                // Map cell types to symbols for display
                switch (cell) {
                case 0:
                    symbol = " ";
                    break;
                case 1:
                    symbol = "#";
                    break;
                case 2:
                    symbol = "S";
                    break;
                case 3:
                    symbol = "G";
                    break;
                case 4:
                    symbol = "A";
                    break;
                case 5:
                    symbol = "P";
                    break;
                case 6:
                    symbol = "F";
                    break;
                case 7:
                    symbol = "SP";
                    break;
                case 8:
                    symbol = "@";
                    break;
                default:
                    symbol = "?";
                    break;
                }

                cout << symbol << ' ';
            }
            cout << endl;
        }
    }

    //Function to display a maze
    void displayMaze(const vector<vector<CellType>>& customMaze) const {
        for (const auto& row : customMaze) {
            for (const auto& cell : row) {
                string symbol;

                // Map cell types to symbols for display
                switch (cell) {
                case 0:
                    symbol = " ";
                    break;
                case 1:
                    symbol = "#";
                    break;
                case 2:
                    symbol = "S";
                    break;
                case 3:
                    symbol = "G";
                    break;
                case 4:
                    symbol = "A";
                    break;
                case 5:
                    symbol = "P";
                    break;
                case 6:
                    symbol = "F";
                    break;
                case 7:
                    symbol = "SP";
                    break;
                case 8:
                    symbol = "@";
                    break;
                default:
                    symbol = "?";
                    break;
                }

                cout << symbol << ' ';
            }
            cout << endl;
        }
    }

    //Function to display the final path taken by the agent
    void displayFinalPath(const stack<Position>& path) const {
        vector<vector<CellType>> tempMaze = maze;

        stack<Position> pathCopy = path;
        while (!pathCopy.empty()) {
            Position pos = pathCopy.top();
            pathCopy.pop();
            tempMaze[pos.row][pos.col] = AGENT;
        }

        cout << "Final Path:" << endl;
        displayMaze(tempMaze);
    }

    //Turning left function
    void turnLeft() {
        // Implement turning left logic
        switch (direction) {
        case UP:
            direction = LEFT;
            break;
        case LEFT:
            direction = DOWN;
            break;
        case DOWN:
            direction = RIGHT;
            break;
        case RIGHT:
            direction = UP;
            break;
        }
    }


    //Turning right function
    void turnRight() {
        // Implement turning right logic
        switch (direction) {
        case UP:
            direction = RIGHT;
            break;
        case RIGHT:
            direction = DOWN;
            break;
        case DOWN:
            direction = LEFT;
            break;
        case LEFT:
            direction = UP;
            break;
        }
    }

    //Moving left function + update score
    void moveLeft() {
        turnLeft();
        score += stepWidth;
    }

    //Moving right function + update score
    void moveRight() {
        turnRight();
        score += stepWidth;
    }

    //Function to handle boosters(e.g., goggles, speed potion)
    void handleBooster(CellType cell) {
        switch (cell) {
        case 4:
            perceptiveField = min(perceptiveField + 1, 3);
            break;
        case 5:
            stepWidth = min(stepWidth + 1, 3);
            break;
            // Handle other boosters if needed
        }
    }

    //Function to handle hurdles (e.g., fog, slowpoke potion)
    void handleHurdle(CellType cell) {
        switch (cell) {
        case 6:
            perceptiveField = max(perceptiveField - 1, 1);
            break;
        case 7:
            stepWidth = max(stepWidth - 1, 1);
            break;
            // Handle other hurdles if needed
        }
    }


public:
    // Constructor to initialize the maze with an initial configuration
    Maze(const vector<vector<CellType>>& initialMaze) {
        maze = initialMaze;
        initializeVisited();
        findStartAndGoal();
    }

    // Function to find the starting and goal positions in the maze
    void findStartAndGoal() {
        for (int i = 0; i < maze.size(); ++i) {
            for (int j = 0; j < maze[i].size(); ++j) {
                if (maze[i][j] == START) {
                    start = { i, j };
                }
                else if (maze[i][j] == GOAL) {
                    goal = { i, j };
                }
            }
        }
    }

    // Depth-first search algorithm to navigate the maze
    stack<Position> depthFirstSearch() {
        while (!pathStack.empty()) {
            pathStack.pop();
        }

        stack<Position> stack;
        stack.push(start);
        pathStack.push(start);
        markVisited(start.row, start.col);

        while (!stack.empty()) {
            Position current = stack.top();
            stack.pop();

            int row = current.row;
            int col = current.col;

            if (row == goal.row && col == goal.col) {
                cout << "Goal reached!" << endl;
                displayFinalPath(pathStack);
                return pathStack;
            }

            bool moved = false;

            // Check if moving up is a valid move
            for (int i = 1; i <= stepWidth; ++i) {
                if (isValidMove(row - i, col)) { // Move Up
                    stack.push({ row - i, col });
                    markVisited(row - i, col);
                    handleBooster(maze[row - i][col]); // Handle booster
                    handleHurdle(maze[row - i][col]);   // Handle hurdle
                    pathStack.push({ row - i, col });
                    moved = true;
                }
            }

            // Check if moving down is a valid move
            for (int i = 1; i <= stepWidth; ++i) {
                if (isValidMove(row + i, col)) { // Move Down
                    stack.push({ row + i, col });
                    markVisited(row + i, col);
                    handleBooster(maze[row + i][col]); // Handle booster
                    handleHurdle(maze[row + i][col]);   // Handle hurdle
                    pathStack.push({ row + i, col });
                    moved = true;
                }
            }

            // Check if moving left is a valid move
            for (int i = 1; i <= stepWidth; ++i) {
                if (isValidMove(row, col - i)) { // Move Left
                    stack.push({ row, col - i });
                    markVisited(row, col - i);
                    handleBooster(maze[row][col - i]); // Handle booster
                    handleHurdle(maze[row][col - i]);   // Handle hurdle
                    moveLeft();
                    pathStack.push({ row, col - i });
                    moved = true;
                }
            }

            // Check if moving right is a valid move
            for (int i = 1; i <= stepWidth; ++i) {
                if (isValidMove(row, col + i)) { // Move Right
                    stack.push({ row, col + i });
                    markVisited(row, col + i);
                    handleBooster(maze[row][col + i]); // Handle booster
                    handleHurdle(maze[row][col + i]);   // Handle hurdle
                    moveRight();
                    pathStack.push({ row, col + i });
                    moved = true;
                }
            }

            // If no valid move, backtrack
            if (!moved) {
                pathStack.pop(); // Backtrack
            }

            // Display the agent's current position in the maze
            displayAgent(current);
        }

        return pathStack;
    }

    // Function to get the final score achieved by the agent
    int getScore() const {
        return score;
    }
};

std::vector<std::vector<CellType>> readMazeFromFile(const std::string& filename) {
    std::ifstream file(filename);
    std::vector<std::vector<CellType>> maze;
    std::string line;

    while (std::getline(file, line)) {
        std::vector<CellType> row;
        for (char c : line) {
            CellType cellType;
            switch (c) {
            case '0':
                cellType = EMPTY;
                break;
            case '1':
                cellType = WALL;
                break;
            case '2':
                cellType = START;
                break;
            case '3':
                cellType = GOAL;
                break;
            case '4':
                cellType = GOGGLES;
                break;
            case '5':
                cellType = SPEED_POTION;
                break;
            case '6':
                cellType = FOG;
                break;
            case '7':
                cellType = SLOWPOKE_POTION;
                break;
            case '8':
                cellType = AGENT;
                break;
            default:
                // Skip invalid characters
                continue;
            }
            row.push_back(cellType);
        }
        maze.push_back(row);
    }

    return maze;
}



//Main function
int main() {
    std::string filename = "C:/Users/micha/MAZE2.txt"; 
    std::vector<std::vector<CellType>> maze = readMazeFromFile(filename);

    Maze mazeSolver(maze);
    mazeSolver.depthFirstSearch();

    std::cout << "Final score: " << mazeSolver.getScore() << std::endl;

    return 0;
}


